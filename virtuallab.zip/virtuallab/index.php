<!DOCTYPE html>
<html>
<head>
<title>WEBSITE</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">My Website</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">lol</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
     
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/c.jpg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
      <h5 class="p-2 text-dark bg-white text-center">I have delivered us to where we are</h5>
      <p>1</p>
    </div>
    </div>
    <div class="carousel-item">
      <img src="images/a.jpg" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
      <h5 class="p-2 text-dark bg-white text-center">I have Journeyed Farther</h5>
      <p>2</p>
    </div>
    </div>
    <div class="carousel-item">
      <img src="images/b.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
      <h5 class="p-2 text-dark bg-white text-center">I am everything I have learnt and more.</h5>
      <p>3</p>
    </div>
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<section class="my-5">
  <div class="py-3">
    <h1 class="text-center">About Us</h1>
</div>
<div class="container-fluid">
  <div class="row">
   <div class="col-lg-6 col-md-6 col-12" >
     <img src="images/d.jpeg" class="img-fluid aboutimg">
   </div>
   <div class="col-lg-6 col-md-6 col-12" >
     <h2 class="display-4">SOME TEXT</h2>
     <p class="py-5">MORE TEXT.</p>
       <a href="about.php" class="btn btn-success">Click Here</a>
   </div>
</div>
</section>

<section class="my-5">
  <div class="py-3">
    <h1 class="text-center">Services</h1>
  </div>
  <div class="container-fluid">
   <div class="row">
    <div class="col-lg-4 col-md-4 col-12" >
     <div class="card">
      <img class="card-img-top" src="images/shin.jpg" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">Click 1</h4>
          <p class="card-text">IMAGE A</p>
          <a href="#" class="btn btn-primary">View</a>
     </div>
    </div>
   </div>
   <div class="col-lg-4 col-md-4 col-12" >
     <div class="card">
      <img class="card-img-top" src="images/mr.jpg" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">Click 1</h4>
          <p class="card-text">IMAGE B</p>
          <a href="#" class="btn btn-primary">View</a>
     </div>
    </div>
   </div>
   <div class="col-lg-4 col-md-4 col-12" >
     <div class="card">
      <img class="card-img-top" src="images/hiroshi.jpg" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">Click 1</h4>
          <p class="card-text">IMAGE C</p>
          <a href="#" class="btn btn-primary">View</a>
     </div>
    </div>
   </div>
  </div>
  </div>
</section>

<section class="my-5">
  <div class="py-3">
    <h1 class="text-center">Gallery</h1>
  </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/c.jpg" class="img-fluid pb-4">
      </div>
    </div>
  </div>
</section>

<section class="my-5">
  <div class="py-3">
    <h1 class="text-center">Contact Us</h1>
  </div>
  <div class="w-50 m-auto">
    <form action="user.php" method="post">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="name" autocomplete="off" class="form-control">
      </div>
      <div class="form-group">
        <label>Email-Id</label>
        <input type="text" name="email" autocomplete="off" class="form-control">
      </div>
      <div class="form-group">
        <label>Phone</label>
        <input type="text" name="phone" autocomplete="off" class="form-control">
      </div>
      <div class="form-group">
        <label>Comments</label>
        <textarea class="form-control" name="comments"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  <div>
</section>

<footer>
  <p class="p-3 bg-dark text-white text-center">@the_noorfatima</h3>
</footer> 


  <script src="jquery.min.js"></script>
  <script src="popper.min.js"></script>
  <script src="bootstrap.min.js"></script>

</body>
</html>